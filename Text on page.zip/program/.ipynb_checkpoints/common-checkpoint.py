import cv2
import matplotlib.pyplot as plt
import numpy as np

path = r'image_data/'
name = 'text1.jpg'
imagePath = path + name
img = cv2.imread(imagePath)

def show(image):
    plt.imshow(image)
    plt.axis('off')
    plt.show()
    
# def imread(image):
#     image = cv2.imread(image)
#     image = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
#     return image


class Rect:
    def __init__(self,rect, name):
        self.name = name
        self.x1 = rect[0][0]
        self.y1 = rect[0][1]
        self.x2 = rect[1][0]
        self.y2 = rect[1][1]
        self.x3 = rect[2][0]
        self.y3 = rect[2][1]
        self.x4 = rect[3][0]
        self.y4 = rect[3][1]
        self.start = min(self.x1,self.x2,self.x3,self.x4)
        self.end = max(self.x1,self.x2,self.x3,self.x4)
        
        # Calculate the length of a character
        self.height = max(self.y1,self.y2,self.y3,self.y4) - min(self.y1,self.y2,self.y3,self.y4)
        
        
        
    @staticmethod
    def relationship(obj1,obj2):
        line1 = obj1.name
        line2 = obj2.name
        
        # Define an error value
        equal_judge = 0.5*(obj1.height+obj2.height)/2 
        
        # Exclude them in one line
        if (obj1.y3+obj1.y4)/2 > (obj2.y1+obj2.y2)/2 or (obj1.y3+obj1.y4)/2 == (obj2.y3+obj2.y4)/2:
            relation = f'****{line1} is not above the {line2}'
            number = 0
            return number,relation
        
        # if two lines'start difference is less than their height, we treat line1 start with line2
        # class 1 relation
        if abs(obj1.start - obj2.start)< equal_judge:
            #if two lines'end difference is less than their height, we treat line1 end with line2
            if abs(obj1.end - obj2.end)< equal_judge:
                number = 1
                relation = f'1.1){line1} and {line2} are equal'
                return number,relation
            
            # relation 1.2
            elif obj1.end < obj2.end:
                number = 2
                relation = f'1.2){line1} start with but ends before {line2}'
                return number,relation
            
            # relation 1.3
            else:
                number = 3
                relation = f'1.3){line1} start with but ends after {line2}'
                return number,relation
            
        # Determine the start of two lines, if line1.start < line2.start, line1 start before line2
        #class 2 relation
        if obj1.start < obj2.start:
            
            # if two lines'end difference is less than their height, we treat line1 ends with line2
            # relation 2.3, line1 ends with but starts before line2
            if abs(obj1.end - obj2.end)< equal_judge:
                number = 6
                relation = f'2.3){line1} ends with but starts before {line2}'
                return number,relation
            
            #then compare the end of line1 and the start of line2
            # if two difference is less than their height, we treat their relation 2.5, line1 ends at start of line2
            if abs(obj2.start - obj1.end)< equal_judge:
                number = 8
                relation = f'2.5){line1} ends at start of {line2}'
                return number,relation
            
            # relation 2.2
            if  obj1.end < obj2.start:
                number = 5
                relation = f'2.2){line1} is all to the left of {line2}'
                return number,relation
            
            # line1's end > line2's start
            # relation 2.1 and 2.4
            else:
                # relation 2.1
                if obj1.end < obj2.end:
                    number = 4
                    relation = f'2.1){line1} overlaps the start of {line2}'
                    return number,relation
                # relation 2.4
                else:
                    number = 7
                    relation = f'2.4){line1} covers {line2}'
                    return number,relation    
        
        # Determine the start of two lines, if line1.start < line2.start, line1 start after line2
        #class 3 relation
        elif obj1.start > obj2.start:
            
            # if two lines'end difference is less than their height, we treat line1 ends with line2
            # relation 3.3, line1 ends with but starts after line2
            if abs(obj1.end - obj2.end)< equal_judge:
                number = 11
                relation = f'3.3){line1} ends with but starts after {line2}'
                return number,relation
            
            #then compare the end of line1 and the start of line2
            # if two difference is less than their height, we treat their relation 3.5, line2 ends at start of line1
            if abs(obj2.end - obj1.start)< equal_judge:
                number = 13
                relation = f'3.5){line1} starts at end of {line2}'
                return number,relation
            
            # relation 3.2
            if  obj2.end < obj1.start:
                number = 10
                relation = f'3.2){line1} is all to the right of {line2}'
                return number,relation
            
            # line1's end > line2's start
            # relation 3.1 and 3.4
            else:
                # relation 3.1
                if obj2.end < obj1.end:
                    number = 9
                    relation = f'3.1){line1} overlaps the end of {line2}'
                    return number, relation
                # relation 3.4
                else:
                    number = 12
                    relation = f'3.4){line1} fits inside {line2}'
                    return number, relation
